Dataset packet provided: JAK2_SC2_initial_packet_to_participants.zip

JAK2_target_D3R_GC3.fasta: Protein sequence file of the JAK2 JH1 catalytic domain construct used in the Kd experiments.

JAK2_SC2_score_compounds_D3R_GC3.csv: CSV file of 89 compounds and their corresponding SMILES strings, target, and subchallenge name.
